package com.icatch.ismartdv2016.Listener;

public interface VideoFramePtsChangedListener {
    void onFramePtsChanged(double d);
}
