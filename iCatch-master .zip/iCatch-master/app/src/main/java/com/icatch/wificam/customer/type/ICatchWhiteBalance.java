package com.icatch.wificam.customer.type;

public class ICatchWhiteBalance {
    public static final int ICH_WB_AUTO = 1;
    public static final int ICH_WB_CLOUDY = 3;
    public static final int ICH_WB_DAYLIGHT = 2;
    public static final int ICH_WB_FLUORESCENT = 4;
    public static final int ICH_WB_TUNGSTEN = 5;
    public static final int ICH_WB_UNDEFINED = 65471;
}
