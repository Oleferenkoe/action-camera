package com.icatch.wificam.customer.type;

public class ICatchTutkMode {
    public static final int ICH_TUTK_MODE_LAN = 8;
    public static final int ICH_TUTK_MODE_NON = 1;
    public static final int ICH_TUTK_MODE_P2P = 2;
    public static final int ICH_TUTK_MODE_RELAY = 4;
}
