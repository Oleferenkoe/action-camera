package com.icatch.wificam.customer.exception;

public class IchCaptureImageException extends Exception {
    private static final long serialVersionUID = 1;

    public IchCaptureImageException(String reason) {
        super(reason);
    }
}
