package com.icatch.wificam.customer.type;

public class ICatchTutkType {
    public static final int ICH_TUTK_TYPE_CLIENT = 2;
    public static final int ICH_TUTK_TYPE_NONE = 0;
    public static final int ICH_TUTK_TYPE_SERVER = 1;
    public static final int ICH_TUTK_TYPE_TUNNEL = 3;
}
