package com.icatch.ismartdv2016.BaseItems;

public enum FileType {
    FILE_VIDEO,
    FILE_PHOTO
}
