package com.icatch.wificam.customer.exception;

public class IchDeviceException extends Exception {
    private static final long serialVersionUID = 1;

    public IchDeviceException(String reason) {
        super(reason);
    }
}
