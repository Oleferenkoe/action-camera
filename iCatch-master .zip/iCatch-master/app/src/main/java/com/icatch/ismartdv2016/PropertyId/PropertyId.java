package com.icatch.ismartdv2016.PropertyId;

public class PropertyId {
    public static final int BURST_NUMBER = 20504;
    public static final int CAMERA_CONNECT_CHANGE = 55201;
    public static final int CAMERA_DATE = 20497;
    public static final int CAMERA_ESSID = 55356;
    public static final int CAMERA_NAME = 55345;
    public static final int CAMERA_PASSWORD = 55357;
    public static final int CAMERA_PASSWORD_NEW = 55346;
    public static final int CAPTURE_DELAY = 20498;
    public static final int CAPTURE_DELAY_MODE = 55280;
    public static final int DATE_STAMP = 54791;
    public static final int ESSID_NAME = 55348;
    public static final int ESSID_PASSWORD = 55349;
    public static final int IMAGE_SIZE = 20483;
    public static final int LIGHT_FREQUENCY = 54790;
    public static final int NOTIFY_FW_TO_SHARE_MODE = 55291;
    public static final int SERVICE_ESSID = 55350;
    public static final int SERVICE_PASSWORD = 55351;
    public static final int SLOW_MOTION = 54805;
    public static final int TIMELAPSE_MODE = 60928;
    public static final int UP_SIDE = 54804;
    public static final int VIDEO_RECORDING_TIME = 55293;
    public static final int VIDEO_SIZE = 54789;
    public static final int VIDEO_SIZE_FLOW = 55292;
    public static final int WHITE_BALANCE = 20485;
}
