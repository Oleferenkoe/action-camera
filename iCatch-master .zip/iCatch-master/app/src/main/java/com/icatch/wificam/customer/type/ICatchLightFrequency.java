package com.icatch.wificam.customer.type;

public class ICatchLightFrequency {
    public static final int ICH_LIGHT_FREQUENCY_50HZ = 0;
    public static final int ICH_LIGHT_FREQUENCY_60HZ = 1;
    public static final int ICH_LIGHT_FREQUENCY_AUTO = 2;
    public static final int ICH_LIGHT_FREQUENCY_UNDEFINED = 255;
}
