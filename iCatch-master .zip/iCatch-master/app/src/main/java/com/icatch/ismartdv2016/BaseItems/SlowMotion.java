package com.icatch.ismartdv2016.BaseItems;

public class SlowMotion {
    public static int SLOW_MOTION_OFF = 0;
    public static int SLOW_MOTION_ON = 1;
}
