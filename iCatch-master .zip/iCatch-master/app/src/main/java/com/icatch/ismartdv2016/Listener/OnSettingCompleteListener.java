package com.icatch.ismartdv2016.Listener;

public interface OnSettingCompleteListener {
    void onOptionSettingComplete();

    void settingTimeLapseModeComplete(int i);

    void settingVideoSizeComplete();
}
