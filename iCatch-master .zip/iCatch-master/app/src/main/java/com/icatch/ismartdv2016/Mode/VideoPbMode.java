package com.icatch.ismartdv2016.Mode;

public enum VideoPbMode {
    MODE_VIDEO_PLAY,
    MODE_VIDEO_IDLE,
    MODE_VIDEO_PAUSE
}
