package com.icatch.wificam.customer.type;

public enum ICatchFileType {
    ICH_TYPE_IMAGE,
    ICH_TYPE_VIDEO,
    ICH_TYPE_AUDIO,
    ICH_TYPE_TEXT,
    ICH_TYPE_ALL,
    ICH_TYPE_UNKNOWN
}
