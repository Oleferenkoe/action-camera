package com.icatch.ismartdv2016.BaseItems;

public class TimeLapseMode {
    public static final int TIME_LAPSE_MODE_STILL = 0;
    public static final int TIME_LAPSE_MODE_VIDEO = 1;
}
