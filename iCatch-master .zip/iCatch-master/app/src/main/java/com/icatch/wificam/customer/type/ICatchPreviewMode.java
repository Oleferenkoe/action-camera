package com.icatch.wificam.customer.type;

public enum ICatchPreviewMode {
    ICH_STILL_PREVIEW_MODE,
    ICH_VIDEO_PREVIEW_MODE,
    ICH_TIMELAPSE_STILL_PREVIEW_MODE,
    ICH_TIMELAPSE_VIDEO_PREVIEW_MODE
}
