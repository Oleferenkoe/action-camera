package com.icatch.ismartdv2016.BaseItems;

public enum LoadImageType {
    LOCAL_PHOTO,
    LOCAL_VIDEO,
    CAMERA_PHOTO,
    CAMERA_VIDEO
}
