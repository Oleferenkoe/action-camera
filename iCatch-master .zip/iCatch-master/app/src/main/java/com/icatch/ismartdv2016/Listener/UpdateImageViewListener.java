package com.icatch.ismartdv2016.Listener;

import android.graphics.Bitmap;

public interface UpdateImageViewListener {
    void onBitmapLoadComplete(String str, Bitmap bitmap);
}
