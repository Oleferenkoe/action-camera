package com.icatch.ismartdv2016.Mode;

public class PreviewLaunchMode {
    public static final int RT_PREVIEW_MODE = 2;
    public static final int VIDEO_PB_MODE = 1;
}
