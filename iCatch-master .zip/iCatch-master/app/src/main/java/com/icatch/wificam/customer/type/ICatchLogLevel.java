package com.icatch.wificam.customer.type;

public enum ICatchLogLevel {
    ICH_LOG_LEVEL_ERROR,
    ICH_LOG_LEVEL_WARN,
    ICH_LOG_LEVEL_INFO,
    ICH_LOG_LEVEL_CONNECT
}
