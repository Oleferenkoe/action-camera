package com.icatch.wificam.customer.exception;

public class IchSocketException extends Exception {
    private static final long serialVersionUID = 1;

    public IchSocketException(String reason) {
        super(reason);
    }
}
