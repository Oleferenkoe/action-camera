package com.icatch.ismartdv2016.BaseItems;

public class Upside {
    public static final int UPSIDE_OFF = 0;
    public static final int UPSIDE_ON = 1;
}
