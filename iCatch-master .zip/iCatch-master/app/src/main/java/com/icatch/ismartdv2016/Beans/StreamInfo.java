package com.icatch.ismartdv2016.Beans;

public class StreamInfo {
    public int bitrate;
    public int fps;
    public int height;
    public String mediaCodecType;
    public int width;
}
