package com.icatch.wificam.customer.type;

public interface ICatchStreamParam {
    String getCmdLineParam();

    int getVideoHeight();

    int getVideoWidth();
}
