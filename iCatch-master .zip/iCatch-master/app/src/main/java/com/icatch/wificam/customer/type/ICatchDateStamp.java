package com.icatch.wificam.customer.type;

public class ICatchDateStamp {
    public static final int ICH_DATE_STAMP_DATE = 2;
    public static final int ICH_DATE_STAMP_DATE_TIME = 3;
    public static final int ICH_DATE_STAMP_OFF = 1;
    public static final int ICH_DATE_STAMP_UNDEFINED = 255;
}
