package com.icatch.wificam.customer.exception;

public class IchDevicePropException extends Exception {
    private static final long serialVersionUID = 1;

    public IchDevicePropException(String reason) {
        super(reason);
    }
}
