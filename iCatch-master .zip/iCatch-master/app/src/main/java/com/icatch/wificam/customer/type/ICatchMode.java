package com.icatch.wificam.customer.type;

public enum ICatchMode {
    ICH_MODE_CAMERA,
    ICH_MODE_VIDEO,
    ICH_MODE_TIMELAPSE,
    ICH_MODE_UNDEFINED
}
