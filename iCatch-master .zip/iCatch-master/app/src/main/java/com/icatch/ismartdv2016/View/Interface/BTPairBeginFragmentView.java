package com.icatch.ismartdv2016.View.Interface;

import android.widget.BaseAdapter;

public interface BTPairBeginFragmentView {
    void setBTListViewAdapter(BaseAdapter baseAdapter);

    void setListHeader(int i);
}
