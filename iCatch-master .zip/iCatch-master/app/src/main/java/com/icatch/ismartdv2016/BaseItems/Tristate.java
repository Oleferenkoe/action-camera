package com.icatch.ismartdv2016.BaseItems;

public enum Tristate {
    FALSE,
    NORMAL,
    ABNORMAL
}
