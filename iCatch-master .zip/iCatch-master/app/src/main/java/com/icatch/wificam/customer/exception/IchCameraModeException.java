package com.icatch.wificam.customer.exception;

public class IchCameraModeException extends Exception {
    private static final long serialVersionUID = 1;

    public IchCameraModeException(String reason) {
        super(reason);
    }
}
