package com.icatch.wificam.customer.type;

public class cameraMode {
    public static final int MODE_CAMERA = 3;
    public static final int MODE_IDLE = 4;
    public static final int MODE_SHARED = 2;
    public static final int MODE_TIMELAPSE_STILL = 7;
    public static final int MODE_TIMELAPSE_STILL_OFF = 9;
    public static final int MODE_TIMELAPSE_VIDEO = 8;
    public static final int MODE_TIMELAPSE_VIDEO_OFF = 10;
    public static final int MODE_UNDEFINED = 65471;
    public static final int MODE_VIDEO_OFF = 1;
    public static final int MODE_VIDEO_ON = 17;
}
