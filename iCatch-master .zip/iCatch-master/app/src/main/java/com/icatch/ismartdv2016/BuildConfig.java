package com.icatch.ismartdv2016;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.icatch.ismartdv2016";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 12;
    public static final String VERSION_NAME = "R1.4.7.2";
}
