package com.icatch.wificam.sdk;

public final class R {

    public static final class attr {
    }

    public static final class drawable {
        public static int ic_launcher = com.icatch.ismartdv2016.R.drawable.abc_ab_share_pack_mtrl_alpha;
    }

    public static final class string {
        public static int app_name = com.icatch.ismartdv2016.R.mipmap.ic_launcher;
    }

    public static final class style {
        public static int AppBaseTheme = com.icatch.ismartdv2016.R.layout.abc_action_bar_title_item;
        public static int AppTheme = com.icatch.ismartdv2016.R.layout.abc_action_bar_up_container;
    }
}
