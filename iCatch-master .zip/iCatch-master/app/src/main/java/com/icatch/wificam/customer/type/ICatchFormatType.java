package com.icatch.wificam.customer.type;

public enum ICatchFormatType {
    ICH_FORMAT_TYPE_H264,
    ICH_FORMAT_TYPE_MJPG,
    ICH_FORMAT_TYPE_YUYV
}
