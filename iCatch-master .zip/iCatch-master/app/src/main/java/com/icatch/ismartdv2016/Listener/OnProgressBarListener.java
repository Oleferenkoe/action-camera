package com.icatch.ismartdv2016.Listener;

public interface OnProgressBarListener {
    void onProgressChange(int i, int i2);
}
