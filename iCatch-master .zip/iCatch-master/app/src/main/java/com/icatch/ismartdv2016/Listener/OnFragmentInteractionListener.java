package com.icatch.ismartdv2016.Listener;

public interface OnFragmentInteractionListener {
    void removeFragment();

    void submitFragmentInfo(String str, int i);
}
