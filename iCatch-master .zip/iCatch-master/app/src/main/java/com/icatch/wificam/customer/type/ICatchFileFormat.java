package com.icatch.wificam.customer.type;

public class ICatchFileFormat {
    public static final int FILE_FORMAT_AVI = 2;
    public static final int FILE_FORMAT_MOV = 3;
    public static final int FILE_FORMAT_MP4 = 1;
}
