package com.icatch.ismartdv2016.BaseItems;

public enum PhotoWallPreviewType {
    PREVIEW_TYPE_LIST,
    PREVIEW_TYPE_GRID
}
