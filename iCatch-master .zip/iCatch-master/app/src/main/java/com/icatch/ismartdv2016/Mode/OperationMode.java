package com.icatch.ismartdv2016.Mode;

public enum OperationMode {
    MODE_BROWSE,
    MODE_EDIT
}
