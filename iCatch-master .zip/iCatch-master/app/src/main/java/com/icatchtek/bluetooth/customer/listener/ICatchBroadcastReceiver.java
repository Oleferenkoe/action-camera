package com.icatchtek.bluetooth.customer.listener;

import android.content.Intent;

public interface ICatchBroadcastReceiver {
    void onReceive(Intent intent);
}
