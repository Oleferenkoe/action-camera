package com.icatchtek.bluetooth.customer.exception;

public class IchBluetoothContextInvalidException extends Exception {
    private static final long serialVersionUID = 1;

    public IchBluetoothContextInvalidException(String reason) {
        super(reason);
    }
}
