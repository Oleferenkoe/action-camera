package com.icatchtek.bluetooth.customer.listener;

import com.icatchtek.bluetooth.customer.type.ICatchBluetoothDevice;

public interface ICatchBTDeviceDetectedListener {
    void deviceDetected(ICatchBluetoothDevice iCatchBluetoothDevice);
}
