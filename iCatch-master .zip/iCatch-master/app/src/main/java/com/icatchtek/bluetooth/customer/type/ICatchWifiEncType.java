package com.icatchtek.bluetooth.customer.type;

public enum ICatchWifiEncType {
    ICATCH_WIFI_AP_ENC_TYPE_NON,
    ICATCH_WIFI_AP_ENC_TYPE_WPA,
    ICATCH_WIFI_AP_ENC_TYPE_WEP
}
