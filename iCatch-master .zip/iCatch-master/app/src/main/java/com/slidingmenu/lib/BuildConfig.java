package com.slidingmenu.lib;

public final class BuildConfig {
    public static final boolean DEBUG = true;
}
